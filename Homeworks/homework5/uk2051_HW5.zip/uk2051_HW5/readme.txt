
File AuxilaryFxns.py contains all the arithematic operations
File LangevinSchemes.py contains all the impelemntation of the Langevian MCMC Methods
File driverScript has list of functions that can be called to perform the generate samples for each of the question
File exercise66.py can be run from the terminal directly to get results for exercise66
File exercise65.py can be run from the terminal directly to get results for exercise65
File exercise64.py can be run from the terminal directly to get results for exercise64
All the dependencies are installed when any exercise*.py script is called from command line.
Unfortunately these files still doesn't accept command line arguments, so in case you are running scripts like exercise64.py, exercise65.py and exercise66.py it would take time to generate the data and it creates lot's of plot as well (Beware)