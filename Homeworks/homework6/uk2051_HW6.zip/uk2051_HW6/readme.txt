
File AuxilaryFxns.py contains all the arithematic operations
File ODSN.py contains all the impelemntation and can be executed directly from the terminal as well.