
This python script has the following dependencies: numpy, pyplot in matplotlib, norm in scipy.stats, statsmodels.api and pandas, math, time, Axes3D in mpl_toolkits.mplot3d and tabulate in from tabulate in tabulate.



