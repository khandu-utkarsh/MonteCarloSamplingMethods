
This python script has the following dependencies: numpy, pyplot in matplotlib, statsmodels.api and pandas.

This script has the main executing function in the end named as Run(). You can directly execute this script.

One annoying thing is that figures pop up in between the execution of the code, so one will need to close the figures for code to move forward. I couldn’t fix is due to time constraint but this won’t happen from next assignment onwards.

